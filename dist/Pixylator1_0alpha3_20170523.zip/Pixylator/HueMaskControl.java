

import javax.swing.JComponent;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.BorderFactory;
import javax.swing.event.ChangeEvent;
import javax.swing.event.DocumentEvent;

import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;

import java.util.Properties;

/**
*   The object that represents the control over the hue masks for object detection.
* 
*   Object name, hue onset, hue offset and the corresponding (mask) color can be obtained through
*   their appropriate getter methods (e.g. getName() and so on). For some of the above properties,
*   there are setter methods (setName(), setOnset(), setOffset()) as well, for the purpose of
*   calling from another object.
*
*   Although a HueMaskControl object can be a stand-alone JComponent, a flexible layout can be done
*   by getting individual layout components (such as nameLabel, nameField, huesample etc.) as 
*   public fields.
*
*   TODO: rewrite update methods to use valueIsAdjusting property of JComponent.
*/
public class HueMaskControl extends JComponent
    implements  javax.swing.event.ChangeListener,
                java.awt.event.ActionListener,
                javax.swing.event.DocumentListener
{
    public static final int UI_GRID_WIDTH       = 5;
    public static final int UI_GRID_HEIGHT      = 2;
    public static final int UI_SLIDER_OFFSETX   = 3;
    public static final int UI_SLIDER_WEIGHT    = 3;

    public JLabel       nameLabel    = null;
    public JTextField   nameField    = null;
    public JLabel       onsetLabel   = null;
    public JSlider      onsetSlider  = null;
    public JTextField   onsetField   = null;

    public JLabel       offsetLabel  = null;
    public JSlider      offsetSlider = null;
    public JTextField   offsetField  = null;

    public JLabel       hueSample    = null;


    String      _name       = null;
    int         _onset      = Hue.MINIMUM;
    int         _offset     = Hue.MAXIMUM;
    Color       _color      = Color.WHITE;
    int         _packed     = -1;
    boolean _sliderChanging = false;
    boolean _fieldChanging  = false;

    public HueMaskControl(String name)
    {
        super();
        _name = name;
        setup();
    }

    public boolean saveConfigs(Properties properties, int index)
    {
        String myname = "mask"+String.valueOf(index);
        properties.setProperty(myname+".name", _name);
        properties.setProperty(myname+".onset", String.valueOf(_onset));
        properties.setProperty(myname+".offset", String.valueOf(_offset));
        return true;
    }

    public boolean loadConfigs(Properties properties, int index)
    {
        String myname = "mask"+String.valueOf(index);
        try {
            setName(properties.getProperty(myname+".name"));
            setOnset(Integer.parseInt(properties.getProperty(myname+".onset")));
            setOffset(Integer.parseInt(properties.getProperty(myname+".offset")));
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
    *   implementation for ActionListener (receives events from text fields)
    */
    @Override
    public void actionPerformed(ActionEvent ae)
    {
        if(_fieldChanging == true)
            return;
        Object src = ae.getSource();
        int value = 0;
        if ( src == onsetField )
        {
            try{
                value = Integer.parseInt(onsetField.getText());
                _fieldChanging = true;
                setOnset(value);
                _fieldChanging = false;
            } catch (NumberFormatException e1) {
                _fieldChanging = false;
                onsetField.setText(String.valueOf(_onset));
            } catch (RuntimeException e2) {
                _fieldChanging = false;
                onsetField.setText(String.valueOf(_onset));
            }
        } else if ( src == offsetField )
        {
            try{
                value = Integer.parseInt(offsetField.getText());
                _fieldChanging = true;
                setOffset(value);
                _fieldChanging = false;
            } catch (NumberFormatException e3) {
                _fieldChanging = false;
                setOffset(_offset);
            } catch (RuntimeException e4) {
                _fieldChanging = false;
                setOffset(_offset);
            }
        }
    }

    @Override
    public void changedUpdate(DocumentEvent e)
    {
        handleUpdate(e);
    }

    @Override
    public void insertUpdate(DocumentEvent e)
    {
        handleUpdate(e);
    }

    @Override
    public void removeUpdate(DocumentEvent e)
    {
        handleUpdate(e);
    }

    private void handleUpdate(DocumentEvent e)
    {
        // just assume that this is the 'name' field
        if( _fieldChanging )
            return;

        _fieldChanging = true;
        setName(nameField.getText());
        _fieldChanging = false;
    }

    /**
    *   implementation for ChangeListener (receives from sliders)
    */
    @Override
    public void stateChanged(ChangeEvent e)
    {
        if( _sliderChanging == true )
            return;

        Object src = e.getSource();

        if( src == onsetSlider )
        {
            _sliderChanging = true;
            try{
                setOnset(onsetSlider.getValue());
                _sliderChanging = false;
            } catch (RuntimeException e1) {
                _sliderChanging = false;
                setOnset(_onset);
            }
        } else if ( src == offsetSlider )
        {
            _sliderChanging = true;
            try {   
                setOffset(offsetSlider.getValue());
                _sliderChanging = false;
            } catch (RuntimeException e2) {
                _sliderChanging = false;
                setOffset(_offset);
            }
        }
    }

    /**
    *   tests whether this HueMaskControl contains the specified [0,360] 'hue' value
    *   i.e. in the range [onset, offset).
    */
    public boolean contains(int hue)
    {
        return (hue >= _onset) && (hue < _offset);
    }

    public Color getColor()
    {
        return _color;
    }

    public int getRGB()
    {
        return _packed;
    }

    public String getName()
    {
        return _name;
    }

    public int getOnset()
    {
        return _onset;
    }

    public int getOffset()
    {
        return _offset;
    }

    public static void layoutUI(HueMaskControl mask, java.awt.Container content,
        GridBagLayout layout, int offsetx, int offsety)
    {
        GridBagConstraints con = new GridBagConstraints();

        // add name label
        con.gridx       = offsetx + 0;
        con.gridy       = offsety + 0;
        con.gridwidth   = 1; con.gridheight  = 1;
        con.weightx     = 1;
        con.anchor      = GridBagConstraints.LAST_LINE_START;
        layout.setConstraints(mask.nameLabel, con);
        content.add(mask.nameLabel);

        // add name field
        con.gridx       = offsetx + 0;
        con.gridy       = offsety + 1;
        con.gridwidth   = 1; con.gridheight  = 1;
        con.weightx     = 1;
        con.anchor      = GridBagConstraints.LINE_START;
        layout.setConstraints(mask.nameField, con);
        content.add(mask.nameField);

        // add hue sample
        mask.hueSample.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        con.gridx       = offsetx + 1;
        con.gridy       = offsety + 0;
        con.gridwidth   = 1; con.gridheight  = 2;
        con.fill        = GridBagConstraints.BOTH;
        con.weightx     = 1;
        con.anchor      = GridBagConstraints.CENTER;
        layout.setConstraints(mask.hueSample, con);
        content.add(mask.hueSample);

        // add onset label
        con.gridx       = offsetx + 2;
        con.gridy       = offsety + 0;
        con.gridwidth   = 1; con.gridheight  = 1;
        con.fill        = GridBagConstraints.EAST;
        con.weightx     = 1;
        con.anchor      = GridBagConstraints.LINE_END;
        layout.setConstraints(mask.onsetLabel, con);
        content.add(mask.onsetLabel);

        // add offset label
        con.gridx       = offsetx + 2;
        con.gridy       = offsety + 1;
        con.weightx     = 1;
        layout.setConstraints(mask.offsetLabel, con);
        content.add(mask.offsetLabel);

        // add onset slider
        con.gridx       = offsetx + 3;
        con.gridy       = offsety + 0;
        con.fill        = GridBagConstraints.HORIZONTAL;
        con.weightx     = UI_SLIDER_WEIGHT;
        con.anchor      = GridBagConstraints.CENTER;
        layout.setConstraints(mask.onsetSlider, con);
        content.add(mask.onsetSlider);

        // add offset slider
        con.gridx       = offsetx + 3;
        con.gridy       = offsety + 1;
        con.weightx     = 3;
        layout.setConstraints(mask.offsetSlider, con);
        content.add(mask.offsetSlider);

        // add onset field
        con.gridx       = offsetx + 4;
        con.gridy       = offsety + 0;
        con.fill        = GridBagConstraints.WEST;
        con.weightx     = 1;
        con.anchor      = GridBagConstraints.LINE_START;
        layout.setConstraints(mask.onsetField, con);
        content.add(mask.onsetField);

        // add offset field
        con.gridx       = offsetx + 4;
        con.gridy       = offsety + 1;
        con.weightx     = 1;
        layout.setConstraints(mask.offsetField, con);
        content.add(mask.offsetField);
    }

    public void setName(String name)
    {
        _name = name;
        if(!_fieldChanging)
            nameField.setText(_name);
    }

    /**
    *   actual setter for the onset value.
    *   to prevent infinite loop, flag _sliderChanging or _fieldChanging when updating from UI.
    */
    public void setOnset(int value)
        throws RuntimeException
    {
        if( value < Hue.MINIMUM || value > _offset ){
            throw new RuntimeException();
        }
        _onset = value;
        if( !_sliderChanging ) onsetSlider.setValue(_onset);
        if( !_fieldChanging )  onsetField.setText(String.valueOf(_onset));
        updateSample();
    }

    /**
    *   actual setter for the offset value.
    *   to prevent infinite loop, flag _sliderChanging or _fieldChanging when updating from UI.
    */
    public void setOffset(int value)
        throws RuntimeException
    {
        if( value > Hue.MAXIMUM || value < _onset ){
            throw new RuntimeException();
        }
        _offset = value;
        if( !_sliderChanging ) offsetSlider.setValue(_offset);
        if( !_fieldChanging )  offsetField.setText(String.valueOf(_offset));
        updateSample();
    }

    /**
    *   sets up the GUI components
    */
    private void setup()
    {

        GridBagConstraints con = new GridBagConstraints();

        nameLabel       = new JLabel("Object name:");
        // TODO: set alignment

        nameField       = new JTextField(_name, 10);
        nameField.getDocument().addDocumentListener(this);

        hueSample       = new JLabel("    \n    \n");
        hueSample.setOpaque(true);
        updateSample();

        onsetLabel      = new JLabel("Onset: ");
        // TODO: set alignment
        offsetLabel     = new JLabel("Offset: ");
        // TODO: set alignment

        onsetSlider     = new JSlider(JSlider.HORIZONTAL, Hue.MINIMUM, Hue.MAXIMUM, _onset);
        onsetSlider.addChangeListener(this);

        onsetField      = new JTextField(String.valueOf(_onset), 4);
        onsetField.addActionListener(this);

        offsetSlider    = new JSlider(JSlider.HORIZONTAL, Hue.MINIMUM, Hue.MAXIMUM, _offset);
        offsetSlider.addChangeListener(this);

        offsetField      = new JTextField(String.valueOf(_offset), 4);
        offsetField.addActionListener(this);

        GridBagLayout gridbag = new GridBagLayout();
        setLayout(gridbag);
        layoutUI(this, this, gridbag, 0, 0);
    }

    /**
    *   change the color sample, following the change in onset or offset
    */
    private void updateSample()
    {
        _color = Hue.getColor((_onset + _offset)/2);
        hueSample.setBackground(_color);
        _packed = _color.getRGB() & 0xFFFFFF;
    }

    public static void main(String[] args)
    {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(new HueMaskControl("test"));
        frame.setSize(600, 180);
        frame.setVisible(true);
    }
}
