

public interface ActionDelegate
{
    void performAction(String command);
}